<?php
function p99_settings_init() {
    register_setting( 'p99_settings', 'p99_items_to_show', ['default' => 'All',] );
    register_setting( 'p99_settings', 'p99_enable_backups', ['default' => 'on',] );
    register_setting( 'p99_settings', 'p99_items_to_backup', ['default' => 'All',] );
    register_setting( 'p99_settings', 'p99_backups_to_keep', ['default' => '3',] );
}
add_action( 'admin_init', 'p99_settings_init' );

// Create the backup folder if it doesn't exist
if ( ! file_exists( WP_CONTENT_DIR . '/99backup/' ) ) {
    wp_mkdir_p( WP_CONTENT_DIR . '/99backup/' );
}

// Hook into the wp_ajax_ action to handle the AJAX request for rolling back a plugin
add_action( 'wp_ajax_p99_rollback_plugin', 'p99_rollback_plugin' );

function p99_rollback_plugin() {
	// Check if the user has the required permission
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'You do not have sufficient permissions to access this page.' );
	}
	// Get the plugin slug and the selected backup file from the AJAX request
	$plugin_slug = sanitize_text_field( $_POST['plugin_slug'] );
	$backup_file = sanitize_text_field( $_POST['backup_file'] );

	// Open the ZIP file
	$zip = new ZipArchive;
	$result = $zip->open( $backup_file );

	if ( $result !== true ) {
		wp_die( 'Error opening ZIP file: ' . $result );
	}
	// Delete the current version of the plugin
	deactivate_plugins( $plugin_slug );
	delete_plugins( array( $plugin_slug ) );
    
	// Extract the backup to the plugins directory
	$result = $zip->extractTo( WP_PLUGIN_DIR );

	// Close the ZIP file
	$zip->close();

    // Clean the plugins cache to force refresh the update information
    wp_clean_plugins_cache( false );

	// Reactivate the plugin
	$result = activate_plugin( $plugin_slug );

	if ( is_wp_error( $result ) ) {
	  wp_send_json_error();
	} else {
	  wp_send_json_success();
	}
}
// Hook into the upgrader_pre_install action
add_action( 'upgrader_pre_install', 'p99_backup_plugin_before_update', 10, 2 );

function p99_backup_plugin_before_update( $true, $args ) {
	// Check if the plugin slug is not empty
	if ( ! empty( $args['plugin'] ) && get_option( 'p99_enable_backups' ) ) {

		// Get the plugin info
        $plugin = plugin_basename( $args['plugin'] );

        $plugin_folder = WP_PLUGIN_DIR . '/' . dirname( $plugin );
        $plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $args['plugin'] );
        $main_plugin_file = WP_PLUGIN_DIR . '/' . $plugin;
        $p99_plugin = file_exists( $plugin_folder . '/99plugs' ) || ( $plugin_data['Name'] == "99Plugs Update Manager" );
        $p99_items_to_backup = get_option( 'p99_items_to_backup' );
        
        if ( $p99_items_to_backup == '99Plugs' ) {
            $p99_plugin = file_exists( $plugin_folder . '/99plugs' ) || ( $plugin_data['Name'] == "99Plugs Update Manager" );
            if ( ! $p99_plugin ) {
                return $true;
            }
        }
        // Calculate the backup folder path
        $backup_folder = WP_CONTENT_DIR . '/99backup/' . basename( $plugin_folder );

        // Create the backup folder if it doesn't exist
        if ( ! file_exists( $backup_folder ) ) {
            wp_mkdir_p( $backup_folder );
        }
        // Get the plugin data
        $plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $args['plugin'] );

        // Calculate the backup filename
        $backup_filename = $backup_folder . '/' . basename( $plugin_folder ) . '-' . $plugin_data['Version'] . '.zip';

        // Zip up the plugin folder
        $zip = new ZipArchive();
        if ( $zip->open( $backup_filename, ZipArchive::CREATE ) ) {
            // Add the plugin folder to the zip archive
            $zip->addEmptyDir( basename( $plugin_folder ) );

            // Get a list of all files in the plugin folder
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $plugin_folder ),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ( $files as $name => $file ) {
                // Skip directories (they will be added automatically)
                if ( ! $file->isDir() ) {
                    
                    // Get the real path of the file
                    $file_path = $file->getRealPath();

                    // Add the file to the zip
                    $zip->addFile( $file_path, basename( $plugin_folder ) . '/' . substr( $file_path, strlen( $plugin_folder ) + 1 ) );
                }
            }
            // Close the zip file
            $zip->close();
        }
        // Get the backup folder for this plugin
        $backup_folder = WP_CONTENT_DIR . '/99backup/' . basename( $plugin_folder );

        // Get a list of all backups for this plugin
        $backups = glob( $backup_folder . '/*.zip' );

        // Sort the backups by modified time
        usort( $backups, function( $a, $b ) {
            return filemtime( $a ) < filemtime( $b );
        } );

        // Delete the oldest backups until there are only 3 left
        while ( count( $backups ) > get_option( 'p99_backups_to_keep')) {
            // Delete the oldest backup
            unlink( array_pop( $backups ) );
        }
	}
	// Return the value of $true to allow the update to proceed
	return $true;
}
// Hook into the wp_ajax_ action to handle the AJAX request for rolling back a theme
add_action( 'wp_ajax_p99_rollback_theme', 'p99_rollback_theme' );

function p99_rollback_theme() {
	// Check if the user has the required permission
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'You do not have sufficient permissions to access this page.' );
	}

	// Get the theme slug and the selected backup file from the AJAX request
	$theme_slug = sanitize_text_field( $_POST['theme_slug'] );
	$backup_file = sanitize_text_field( $_POST['backup_file'] );

	// Open the ZIP file
	$zip = new ZipArchive;
	$result = $zip->open( $backup_file );

	if ( $result !== true ) {
		wp_die( 'Error opening ZIP file: ' . $result );
	}

	// Delete the current version of the theme
	switch_theme( WP_DEFAULT_THEME );
	delete_theme( $theme_slug );

	// Extract the backup to the themes directory
	$result = $zip->extractTo( WP_CONTENT_DIR . '/themes' );

	// Close the ZIP file
	$zip->close();

    // Clean the themes cache to force refresh the update information
    wp_clean_themes_cache( false );

	// Activate the theme
	switch_theme( $theme_slug );

	if ( is_wp_error( $result ) ) {
	  wp_send_json_error();
	} else {
	  wp_send_json_success();
	}
}
// Hook into the upgrader_pre_install action
add_action( 'upgrader_pre_install', 'p99_backup_theme_before_update', 10, 2 );

function p99_backup_theme_before_update( $true, $args ) {
	// Check if the theme slug is not empty
	if ( ! empty( $args['theme'] ) ) {
		// Get the theme info
		$theme = $args['theme'];

        // Calculate the theme folder path
        $theme_folder = get_theme_root() . '/' . $theme;

        // Calculate the backup folder path
        $backup_folder = WP_CONTENT_DIR . '/99backup/' . basename( $theme_folder );

        // Create the backup folder if it doesn't exist
        if ( ! file_exists( $backup_folder ) ) {
            wp_mkdir_p( $backup_folder );
        }

        // Get the theme data
        $theme_data = wp_get_theme( $theme );

        // Calculate the backup filename
        $backup_filename = $backup_folder . '/' . $theme . '-' . $theme_data->get('Version') . '.zip';

        // Zip up the theme folder
        $zip = new ZipArchive();
        if ( $zip->open( $backup_filename, ZipArchive::CREATE ) ) {
            // Add the theme folder to the zip archive
            $zip->addEmptyDir( $theme );

            // Get a list of all files in the theme folder
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $theme_folder ),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ( $files as $name => $file ) {
                // Skip directories (they will be added automatically)
                if ( ! $file->isDir() ) {
                    // Get the real path of the file
                    $file_path = $file->getRealPath();

                    // Add the file to the zip
                    $zip->addFile( $file_path, $theme . '/' . substr( $file_path, strlen( $theme_folder ) + 1 ) );
                }
            }
            // Close the zip file
            $zip->close();
        }
        // Get the backup folder for this theme
        $backup_folder = WP_CONTENT_DIR . '/99backup/' . basename( $theme_folder );

        // Get a list of all backups for this theme
        $backups = glob( $backup_folder . '/*.zip' );

        // Sort the backups by modified time
        usort( $backups, function( $a, $b ) {
            return filemtime( $a ) < filemtime( $b );
        } );
        // Delete the oldest backups until there are only 3 left
        while ( count( $backups ) > get_option( 'p99_backups_to_keep')) {
            // Delete the oldest backup
            unlink( array_pop( $backups ) );
        }
	}
	// Return the value of $true to allow the update to proceed
	return $true;
}