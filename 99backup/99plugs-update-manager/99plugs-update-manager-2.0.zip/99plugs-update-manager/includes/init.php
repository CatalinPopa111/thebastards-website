<?php
add_action('admin_menu', 'p99_add_submenu');

function p99_add_submenu() {
  add_submenu_page('tools.php', '99Plugs', '99Plugs', 'manage_options', 'p99-manager', 'p99_manager_callback');
}
function p99_manager_callback() {
	include( P99_PLUGIN_PATH . '/views/tabs.php' );
}
add_action('admin_enqueue_scripts','p99_enqueue_scripts');

function p99_enqueue_scripts() {
  wp_enqueue_style( 'p99-style-css', P99_PLUGIN_URL . 'assets/css/style.css?v=2.0');
  wp_enqueue_script( 'p99-ajaxForm-js', P99_PLUGIN_URL . 'assets/js/ajaxForm.js');
  wp_enqueue_script( 'p99-custom-js', P99_PLUGIN_URL . 'assets/js/custom.js');
  wp_enqueue_script( 'p99-custom-js', P99_PLUGIN_URL . 'assets/js/custom.js');
  wp_localize_script('p99-custom-js', 'jsObject', array( 'ajaxURL' => admin_url( 'admin-ajax.php' )));
}
add_filter('plugin_action_links_'.P99_PLUGIN_BASE, 'p99_links');

function p99_links( $links ) {
	$links[] = '<a href="' . admin_url( 'tools.php?page=p99-manager' ) . '">' . __('Update Keys') . '</a>';
	return $links;
}
function p99_load_priority(){
  $path = plugin_basename(dirname(__FILE__)).'/'.basename(__FILE__);
  if($plugins = get_option('active_plugins')){
	  if($key = array_search($path, $plugins)){
		  array_splice($plugins, $key, 1);
		  array_unshift($plugins, $path);
		  update_option('active_plugins', $plugins);
    }
	}
}
add_action('activated_plugin', 'p99_load_priority');

if (!function_exists('p99_fetchkey')){
  function p99_fetchkey($name) {
    if (empty($name)) return;
    $apikeys = get_option('apikeys');
    if (empty($apikeys)) return;
    $vyear = 'VIP Access Pass (365 Days)';
    $vlife = 'VIP Access Pass (Lifetime)';
    $key = 'NOKEYFOUND';
    foreach ($apikeys as $apikey):
      if (in_array($vlife, $apikey) || in_array($vyear, $apikey) ) {
        $key = isset($apikey['keyvalue']) ? $apikey['keyvalue'] : '';
        break;
      }
      elseif (in_array($name, $apikey)) {
        $key = isset($apikey['keyvalue']) ? $apikey['keyvalue'] : '';
        break;
      }
    endforeach;
    return $key;
  }
}
if (!function_exists('get_plugins')){
  require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
function p99_pluglist(){
  $pluglist = array();
  $plugins = get_plugins();
  foreach ($plugins as $key=>$value) {
    $plugin_folders = explode('/',$key)[0];
    if (file_exists(WP_PLUGIN_DIR . '/' . $plugin_folders .'/99plugs')) {
      $pluglist[] = $key;
    }
  }
  return $pluglist;
}
if (!function_exists('p99_dupechk')) {
  function p99_dupechk($needle, $haystack, $strict = false) {
    if(is_array($haystack)) {
      foreach ($haystack as $item) {
        if (($strict ? $item === $needle : $item == $needle)
        || (is_array($item) && p99_dupechk($needle, $item, $strict))) {
          return true;
        }
      }
    }
    return false;
  }
}