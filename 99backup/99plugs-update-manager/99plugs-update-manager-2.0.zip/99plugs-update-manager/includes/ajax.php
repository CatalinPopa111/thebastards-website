<?php
class p99_ajax {
  function __construct() {
    add_action('wp_ajax_p99_save_data', array($this, 'p99_save_data'));
    add_action('wp_ajax_nopriv_p99_save_data', array($this, 'p99_save_data'));
  }
  public function p99_save_data() {
    $data     = $_POST['data'];
    $saveObj  = [];
    $statuses = [];
    $names    = [];
    $keys     = [];
    $hasEmpty = [];

    if( is_array( $data ) ) {
      $i = 0;
      foreach( $data as $row ) {
        if(empty($row['keyname']) || empty( $row['keyvalue'] )) {
          $row['keystatus'] = ''; // unset status if one field empty
        }
        $i++;
        if(!isset($row['keystatus'])) {
          $row['keystatus'] = '';
        }
        $row['keyname'] = trim(str_replace(array('– Updates (365 Days)','– Updates (Lifetime)','- Updates (365 Days)','- Updates (Lifetime)'),'',$row['keyname']));
        $row['keyvalue'] = trim($row['keyvalue']);
        $row['keystatus'] = trim($row['keystatus']);

        $saveObj[]  = $row;
        $statuses[] = $row['keystatus'];
        $names[]    = $row['keyname'];
        $keys[]     = $row['keyvalue'];
      }
    }
    update_option( 'apikeys',  $saveObj);
    echo json_encode([
      'status'   => 200,
      'message'  => 'Update keys saved.',
      'names'    => $names,
      'keys'     => $keys,
      'statuses' => $statuses
    ]);
    wp_die();
  }
}
new p99_ajax();
