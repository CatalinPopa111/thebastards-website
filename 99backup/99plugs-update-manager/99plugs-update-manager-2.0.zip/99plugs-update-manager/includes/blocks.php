<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

add_filter('http_request_args', function ($r, $url) {
  if(0 === strpos($url,'https://api.wordpress.org/plugins/update-check/1.1/')){
    $plugins = json_decode($r['body']['plugins'], true);
    if (array_key_exists(plugin_basename(PMAIN_100), $plugins['plugins'])) {
      unset($plugins['plugins'][plugin_basename(PMAIN_100)]);
    }
    $r['body']['plugins'] = json_encode($plugins);
  }
  return $r;
}, PHP_INT_MAX, 3);

$pluglist = p99_pluglist();
foreach ($pluglist as $plug) {
  add_filter('pre_set_site_transient_update_plugins', function ($transient) use ( $plug ){
    if (isset($transient) && is_object($transient)) {
      if (isset($transient->response[$plug])) {
        if(strpos($transient->response[$plug]->package,'99plugs') !== false){
        } else {
          unset($transient->response[$plug]);
        }
      }
    }
    return $transient;
  });
  add_filter('pre_site_transient_update_plugins', function ($transient) use ( $plug ){
    if (isset($transient) && is_object($transient)) {
      if (isset($transient->response[$plug])) {
        if(strpos($transient->response[$plug]->package,'99plugs') !== false){
        } else {
          unset($transient->response[$plug]);
        }
      }
    }
    return $transient;
  });
  add_filter('site_transient_update_plugins', function ($transient) use ( $plug ){
    if (isset($transient) && is_object($transient)) {
      if (isset($transient->response[$plug])) {
        if(strpos($transient->response[$plug]->package,'99plugs') !== false){
        } else {
          unset($transient->response[$plug]);
        }
      }
    }
    return $transient;
  });
  add_filter('http_request_args', function ($r, $url) use ( $plug ) {
    if(0 === strpos($url,'https://api.wordpress.org/plugins/update-check/1.1/')){
      $plugins = json_decode($r['body']['plugins'], true);
      if (array_key_exists($plug, $plugins['plugins'])) {
        unset($plugins['plugins'][$plug]);
      }
      $r['body']['plugins'] = json_encode($plugins);
    }
    return $r;
  }, PHP_INT_MAX, 3);
}
