<?php
// Create the backup folder if it doesn't exist
if ( ! file_exists( WP_CONTENT_DIR . '/99backup/' ) ) {
    wp_mkdir_p( WP_CONTENT_DIR . '/99backup/' );
}
add_action( 'wp_ajax_p99_download_plugin_update', 'p99_download_plugin_update' );

function p99_download_plugin_update() {
    // Check if the user has the required permission
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'You do not have sufficient permissions to access this page.' );
    }

    // Get the plugin_slug, filename and download URL from the AJAX request
    $plugin_slug = sanitize_text_field( $_POST['plugin_slug'] );
    $plugin_folder = WP_PLUGIN_DIR . '/' . dirname( $plugin_slug );
    $download_file = sanitize_text_field( $_POST['download_file'] );
    $download_url = sanitize_text_field( $_POST['download_url'] );

    // Local directory to save the file to
    $local_dir = WP_CONTENT_DIR . '/99backup';

    // Check if the backup directory exists, create it if it doesn't
    if ( ! is_dir( $local_dir ) ) {
        mkdir( $local_dir );
    }

    // Get the plugin data
    $plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_slug );

    // Calculate the backup folder path
    $backup_folder = WP_CONTENT_DIR . '/99backup/' . dirname( $plugin_slug);

    // Create the backup folder if it doesn't exist
    if ( ! file_exists( $backup_folder ) ) {
        wp_mkdir_p( $backup_folder );
    }

    // Calculate the backup filename
    $backup_filename = $backup_folder . '/' . basename( $plugin_folder ) . '-' . $plugin_data['Version'] . '.zip';

    // Zip up the plugin folder
    $zip = new ZipArchive();
    if ( $zip->open( $backup_filename, ZipArchive::CREATE ) ) {
        // Add the plugin folder to the zip archive
        $zip->addEmptyDir( basename( WP_PLUGIN_DIR . '/' . dirname( $plugin_slug) ) );

        // Get a list of all files in the plugin folder
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator( WP_PLUGIN_DIR . '/' . dirname( $plugin_slug) ),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ( $files as $name => $file ) {
            // Skip directories (they will be added automatically)
            if ( ! $file->isDir() ) {        
                // Get the real path of the file
                $file_path = $file->getRealPath();

                // Add the file to the zip
                $zip->addFile( $file_path, basename( $plugin_folder ) . '/' . substr( $file_path, strlen( $plugin_folder ) + 1 ) );
            }
        }
        // Close the zip file
        $zip->close();
    }
    // Get a list of all backups for this plugin
    $backups = glob( $backup_folder . '/*.zip' );

    // Sort the backups by modified time
    usort( $backups, function( $a, $b ) {
        return filemtime( $a ) < filemtime( $b );
    } );

    // Delete the oldest backups until there are only 3 left
    while ( count( $backups ) > get_option( 'p99_backups_to_keep' ) ) {
        // Delete the oldest backup
        unlink( array_pop( $backups ) );
    }
    // Filename for the downloaded file
    $filename = $download_file;

    // Check if the file already exists, delete it if it does
    if ( file_exists( $local_dir . '/' . $filename ) ) {
        unlink( $local_dir . '/' . $filename );
    }
    // Download the file and save it to the local directory
    //$file_contents = file_get_contents( $download_url );
    //file_put_contents( $local_dir . '/' . $filename, $file_contents );
   
    $zip_file = $local_dir . '/' . $filename;
    $resource = fopen($zip_file, "w");

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $download_url);
    curl_setopt($ch, CURLOPT_FAILONERROR, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
    curl_setopt($ch, CURLOPT_FILE, $resource);

    $download = curl_exec($ch);

    if(curl_errno($ch)) {
        throw new Exception(curl_error($ch));
    }
    curl_close($ch);
    fclose($resource);

    // Open the ZIP file
    $zip = new ZipArchive;
    $result = $zip->open( $local_dir . '/' . $filename );

    if ( $result !== true ) {
        wp_die( 'Error opening ZIP file: ' . $result );
    }

    // Delete the current version of the plugin
    deactivate_plugins( $plugin_slug );
    delete_plugins( array( $plugin_slug ) );

    // Extract the downloaded files to the plugins directory
    $result = $zip->extractTo( WP_PLUGIN_DIR );

    // Close the ZIP file
    $zip->close();
    
    // Delete the downloaded file
    unlink( $local_dir . '/' . $filename );

    // Clean the plugins cache to force refresh the update information
    wp_clean_plugins_cache( false );

    // Reactivate the plugin
    $result = activate_plugin( $plugin_slug );

    if ( is_wp_error( $result ) ) {
        wp_send_json_error();
    } else {
        wp_send_json_success();
    }
}
