<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;
/*
========================================================
UPDATE KEY ACTIVATION
========================================================
*/
function plugs99_activate() {
  if ( isset($_POST['name']) && isset($_POST['key']) ) {
    $name = $_POST['name'];
    $key = $_POST['key'];

    $api_params = array(
      'edd_action' => 'activate_license',
      'license' => $key,
      'item_name' => urlencode($name) ,
      'url' => home_url()
    );

    $response = wp_remote_post('https://99plugs.com', array(
      'timeout' => 15,
      'sslverify' => false,
      'body' => $api_params
    ));

    $sl_activation = 'false'; // default to false
    if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
      if (is_wp_error($response)) {
        $message = $response->get_error_message();
      } else {
        $message = 'An error occurred, please try again.';
      }
    } else {
      $license_data = json_decode(wp_remote_retrieve_body($response));
      if ($license_data->license == 'valid') {
        $license_status = "Active";
        $sl_activation = 'true';
        $message = 'Activated successfully.'; // Trigger to Silence
      } else {
        $license_status = "Inactive";
        switch ($license_data->license) {
          case 'expired':
            $message = sprintf('Your update key expired on %s.',date_i18n(get_option('date_format'),strtotime($license_data->expires,current_time('timestamp'))));
          break;
          case 'disabled':
          case 'revoked':
            $message = 'Your update key has been disabled.';
          break;
          case 'inactive':
            $message = 'Your update key is no longer active.';
          break;
          case 'site_inactive':
            $message = 'Your update key is not active for this URL.';
          break;
          case 'invalid':
          	if ($license_data->error == 'expired') {
            	$license_status = "Expired";
          		$message = sprintf('Your update key expired on %s.',date_i18n(get_option('date_format'),strtotime($license_data->expires,current_time('timestamp'))));
            } else {
            	$message ='Invalid key. Make sure ITEM NAME and UPDATE KEY match as provided by 99plugs.';
	    }
          break;
          case 'missing':
          case 'item_name_mismatch':
            $message ='Invalid key. Make sure ITEM NAME and UPDATE KEY match as provided by 99plugs.';
          break;
          case 'no_activations_left':
            $message = 'Your update key has reached its activation limit.';
          break;
          default:
            $message = 'An error occurred, please try again.';
          break;
        }
      }
    }
    $apikeys = get_option('apikeys');
    if ( !empty($apikeys) ) {
      foreach($apikeys as $index => $apikey) {
        if($apikey['keyname'] == $name && $apikey['keyvalue'] == $key) {
          $apikeys[$index]['keystatus'] = $license_status;
        }
      }
      update_option('apikeys', $apikeys );
      echo json_encode([
        'status' => 200,
        'message' => $message,
        'state' => $license_status
      ]);
    } else {
      echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
    }
    wp_die();
  }
}
add_action('wp_ajax_plugs99_activate', 'plugs99_activate');

/***********************************************
 * UPDATE KEY DEACTIVATION
 ***********************************************/
function plugs99_deactivate() {
  if ( isset($_POST['name']) && isset($_POST['key']) ) {
    $name = $_POST['name'];
    $key = $_POST['key'];

    $api_params = array(
      'edd_action' => 'deactivate_license',
      'license' => $key,
      'item_name' => urlencode($name) ,
      'url' => home_url()
    );

    $response = wp_remote_post('https://99plugs.com', array(
      'timeout' => 15,
      'sslverify' => false,
      'body' => $api_params
    ));

    $sl_activation = 'false'; // default to false
    if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
      if (is_wp_error($response)) {
        $message = $response->get_error_message();
      } else {
        $message = 'An error occurred, please try again.';
      }
    } else {
      $license_data = json_decode(wp_remote_retrieve_body($response));
      $sl_activation = 'true';
      $message = 'Deactivated successfully.'; // Trigger to Silence
      if ($license_data->license == 'deactivated') {
        $license_status = "Inactive";
      } else {
        $license_status = "Inactive";
      }
    }
    $apikeys = get_option('apikeys');
    if ( !empty($apikeys) ) {
      foreach($apikeys as $index => $apikey) {
        if($apikey['keyname'] == $name && $apikey['keyvalue'] == $key) {
          $apikeys[$index]['keystatus'] = $license_status;
        }
      }
      update_option('apikeys', $apikeys );
      echo json_encode([
        'status' => 200,
        'message' => $message,
        'state' => $license_status
      ]);
    } else {
      echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
    }
    wp_die();
  }
}
add_action('wp_ajax_plugs99_deactivate', 'plugs99_deactivate');

/************************************
 * UPDATE KEY STATUS CHECK
 ************************************/
function plugs99_check() {
  if ( isset($_POST['name']) && isset($_POST['key']) ) {
    $name = $_POST['name'];
    $key = $_POST['key'];

    $api_params = array(
      'edd_action' => 'check_license',
      'license' => $key,
      'item_name' => urlencode($name) ,
      'url' => home_url()
    );

    $response = wp_remote_post('https://99plugs.com', array(
      'timeout' => 15,
      'sslverify' => false,
      'body' => $api_params
    ));

    $sl_activation = 'false'; // default to false
    if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
      if (is_wp_error($response)) {
        $message = $response->get_error_message();
      } else {
        $message = 'An error occurred, please try again.';
      }
    } else {
      $license_data = json_decode(wp_remote_retrieve_body($response));
      if ($license_data->license == 'valid') {
        $license_status = "Active";
        $message = "Your update key is still active.";
        $sl_activation = 'true';
      } else {
        $license_status = "Inactive";
        switch ($license_data->license) {
          case 'expired':
          	$license_status = "Expired";
            $message = sprintf('Your update key expired on %s.',date_i18n(get_option('date_format'),strtotime($license_data->expires,current_time('timestamp'))));
          break;
          case 'disabled':
          case 'revoked':
            $message = 'Your update key has been disabled.';
          break;
          case 'inactive':
            $message = 'Your update key is no longer active.';
          break;
          case 'site_inactive':
            $message = 'Your update key is not active for this URL.';
          break;
          case 'missing':
          case 'invalid':
          case 'item_name_mismatch':
            $message ='Invalid key. Make sure ITEM NAME and UPDATE KEY match as provided by 99plugs.';
          break;
          case 'no_activations_left':
            $message = 'Your update key has reached its activation limit.';
          break;
          default:
            $message = 'An error occurred, please try again.';
          break;
        }
      }
    }
    $apikeys = get_option('apikeys');
    if ( !empty($apikeys) ) {
      foreach($apikeys as $index => $apikey) {
        if($apikey['keyname'] == $name && $apikey['keyvalue'] == $key) {
          $apikeys[$index]['keystatus'] = $license_status;
        }
      }
      update_option('apikeys', $apikeys );
      echo json_encode([
        'status' => 200,
        'message' => $message,
        'state' => $license_status
      ]);
    } else {
      echo json_encode(['status' => 400, 'message' => 'Something went wrong!']);
    }
    wp_die();
  }
}
add_action('wp_ajax_plugs99_check', 'plugs99_check');