<?php
/*
Plugin Name: 99Plugs Update Manager
Plugin URI: https://99plugs.com
Description: Premium Wordpress Plugins and Themes Updater
Version: 2.0
Author: 99Plugs
Author URI: https://99plugs.com
*/
class p99_main {
	private static $instance = null;

	public static function get_instance() {
		if (!self::$instance) {
			self::$instance = new p99_main();
		}
		return self::$instance;
	}
	private function __construct() {
		$this->define();
		$this->includes();
	}
	private function define() {
		define('P99_PLUGIN_PATH', plugin_dir_path(__FILE__));
		define('P99_PLUGIN_URL', plugin_dir_url(__FILE__));
		define('P99_PLUGIN_BASE', plugin_basename( __FILE__ ));
		define('PMAIN_100_VER', '2.0');
		define('PMAIN_100', __FILE__);
	}
	private function includes() {
		include_once( 'includes/init.php' );
		include_once( 'includes/ajax.php' );
		include_once( 'includes/api.php' );
		include_once( 'includes/blocks.php' );
        include_once( 'includes/backup.php' );
        include_once( 'includes/direct.php' );

		if (!class_exists('Plugs99_Plugin_Updater')) {
		  include_once( 'classes/plugin-class.php' );
		}
		if (!class_exists('Plugs99_Theme_Updater')) {
		  include_once( 'classes/theme-class.php' );
		}
	}
}
p99_main::get_instance();
include_once( 'updater/99updater.php' );