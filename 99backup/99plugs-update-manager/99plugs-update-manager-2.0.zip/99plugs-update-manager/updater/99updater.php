<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

define('P99_100', '99Plugs Update Manager');

if (class_exists('Plugs99_Plugin_Updater') && function_exists('p99_fetchkey')) {
  function p99_update_100() {
    $doing_cron = defined('DOING_CRON') && DOING_CRON;
    if (!current_user_can('manage_options') && !$doing_cron) {
      return;
    }
    $key = p99_fetchkey(P99_100);

    $edd_updater = new Plugs99_Plugin_Updater('https://99plugs.com/', PMAIN_100, array(
      'version' => PMAIN_100_VER,
      'license' => $key,
      'item_id' => "100",
      'author' => "99Plugs",
      'url' => home_url()
    ));
  }
  add_action('init', 'p99_update_100');
}
function p99_add2mgr_100() {
  $apikeys = get_option('apikeys');
  //$unser_keys = maybe_unserialize($apikeys);
  $new_key = array();

  if (!p99_dupechk(P99_100, $apikeys)) {
    $new_key['keyname'] = stripslashes(strip_tags(P99_100));
    $new_key['keyvalue'] = '';
    $new_key['keystatus'] = '';
    $apikeys[] = $new_key;
  }
  if (!empty($new_key) && $new_key != $apikeys) {
    update_option('apikeys', $apikeys);
  }
}
register_activation_hook(PMAIN_100, 'p99_add2mgr_100');
