<?php
//Get the active tab from the $_GET param
$default_tab = null;
$tab = isset($_GET['tab']) ? $_GET['tab'] : $default_tab;
?>
<div class="p99-manager">
  <div class="p99-header">
    <div class="p99-logo"></div>
		<div class="p99-title"><h2>99Plugs Update Manager</h2></div>
		<div class="p99-link"><a href="https://99plugs.com" target="_blank">Visit 99Plugs</a></div>
	</div>   
  <nav class="nav-tab-wrapper">
    <a href="?page=p99-manager" class="nav-tab <?php if($tab===null):?>nav-tab-active<?php endif; ?>">Update Keys</a>
    <a href="?page=p99-manager&tab=plugins" class="nav-tab <?php if($tab==='plugins'):?>nav-tab-active<?php endif; ?>">Plugins</a>
    <a href="?page=p99-manager&tab=themes" class="nav-tab <?php if($tab==='themes'):?>nav-tab-active<?php endif; ?>">Themes</a>
    <a href="?page=p99-manager&tab=settings" class="nav-tab <?php if($tab==='settings'):?>nav-tab-active<?php endif; ?>">Settings</a>
  </nav>    
  <div class="tab-content">
    <?php switch($tab) :
      case 'plugins':
      	include( P99_PLUGIN_PATH . '/views/plugins.php' );
        break;
      case 'themes':
      	include( P99_PLUGIN_PATH . '/views/themes.php' );
        break;
      case 'settings':
        include( P99_PLUGIN_PATH . '/views/settings.php' );
        break;
      default:
      	include( P99_PLUGIN_PATH . '/views/keys.php' );
        break;
    endswitch; ?>
  </div>
</div>