=== 99Plugs Update Manager ===
Contributors: 99Plugs
Website Link: https://99plugs.com
Tags: 99plugs, update keys, license keys
Requires at least: 5.0
Tested up to: 
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creates admin interface for storing and activating 99Plugs update keys

== Description ==

Creates admin interface for storing and activating 99Plugs update keys

Features:

*   Easy update key activation and deactivation
*   Auto-update of premium Wordpress plugins and themes
*	Backup plugins and themes before updating
*	Rollback plugins and themes to previous versions

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload "99plugs-update-manager" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the Plugins menu in WordPress.
3. Navigate to the "99Plugs" option in the Settings->Tools Menu.
4. Enter and activate your update keys from 99Plugs

== Frequently Asked Questions ==

= What's this all about? =

Easy update keys activation and deactivation for premium plugins and themes from 99Plugs

== Screenshots ==

1. None

== Changelog ==

= 2.0 =
* New table overview of installed plugins and themes.
* New feature to backup plugins and themes before updating.
* New feature to rollback plugins and themes to previous versions.
* New fallback update system directly within the update manager. 

= 1.53 =
* Improved performance related to update checks
* Updated plugin updater class  

= 1.52 =
* Fixed JQuery conflict.

= 1.51 =
* Fixed updater function conflict.

= 1.50 =
* Improvements to overall file structure and codebase.
* Fixed activation errors on specific web hosting servers.

= 1.42 =
* Updated plugin and theme updater classes 

= 1.41 =
* Minor bug fixes

= 1.40 =
* API class updates and speed improvements 

= 1.39 =
* Fixed class bug preventing updates for several plugins

= 1.38 =
* Improved UI
* Ajaxified API requests 

= 1.37 =
* Added ability to check if update key is still active
* Fixed update notification conflicts 

= 1.36 =
* Added field sanitation to fix common entry errors   

= 1.35 =
* Improved instruction and field wording

= 1.3 =
* Fixed multiple item activation status display
* Added support for new Wordpress Auto Update feature

= 1.2 =
* Fixed broken link destinations
* Added additional information

= 1.1 =
* Minor bug fixes

= 1.0 =
* First release!

== Upgrade Notice ==
