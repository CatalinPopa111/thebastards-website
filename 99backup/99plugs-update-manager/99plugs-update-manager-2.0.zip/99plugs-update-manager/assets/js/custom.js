jQuery( function($) {
	$('.p99-append-row').click(
		function() {
			row = $('.rows-wrapper .row:first-child').prop('outerHTML').replaceAll('[0]', "[" + $('.rows-wrapper .row').length + "]");

			$('.rows-wrapper').append( row ); // clone row with fields
			$('.rows-wrapper .row:last-child input').val('');
			$('.rows-wrapper .row:last-child .no-clone').html('');
		}
	);
	$('#p99-form').ajaxForm({
		dataType: 'json',
    beforeSubmit: function() {
    },
    complete: function (xhr) {
			setTimeout(function() { $('.status-message .notice').hide(); }, 5000);
      $('.status-message').html(`<div class="notice notice-` + ( xhr.responseJSON.status == 200 ? 'success' : 'error' ) + ` is-dismissible"><p>`+ xhr.responseJSON.message +`</p></div>`);

      if(xhr.responseJSON.status == 200 ) {
				for (var i = 0; i < xhr.responseJSON.names.length; i++) {
        	p99ButtonsHandler(
          	xhr.responseJSON.statuses[i],
          	xhr.responseJSON.names[i],
          	xhr.responseJSON.keys[i],
          	$('.rows-wrapper .row:nth-child('+ (i + 1) +')')
        	);
				}
			}
    },
    error: function (xhr) {
      console.log( xhr );
      alert('Something went wrong!');
    }
  });

	$(document).on( 'click', '.remove-btn',  function() {
		$(this).parents('.row').remove();
	});

	$(document).on( 'click', '.dynamic-actions',  function() {
		let $elem = $(this);
		  $parent = $elem.parents('.row');
			$parent.find('.response_status').html(' ');

		$.ajax({
			url: jsObject.ajaxURL,
			method: 'POST',
			dataType: "JSON",
			data: {
				action: $elem.attr('data-action'),
				name: $elem.attr('data-name'),
				key: $elem.attr('data-key')
			},
			success: function(response) {
				$parent.find('.response_status').html( response.message );
      	p99ButtonsHandler(response.state, $elem.attr('data-name'), $elem.attr('data-key'), $parent );
				setTimeout(function() { $('.status-message .notice').hide(); }, 5000);
	      $('.status-message').html(`<div class="notice notice-` + ( response.message == 'Activated successfully.' || response.message == 'Deactivated successfully.' || response.message == 'Your update key is still active.' ? 'success' : 'error' ) + ` is-dismissible"><p>`+ response.message +`</p></div>`);
			}
		})
	});
});

const p99ButtonsHandler = ( status, name, key, $parent ) => {
	let html = '';
	if( status == 'Active' ) {
		html = `<button data-action="plugs99_check" type="button" data-name="`+name+`" data-key="`+key+`" class="button dynamic-actions">CHECK</button>
				<button type="button" data-action="plugs99_deactivate" data-name="`+name+`" data-key="`+key+`" class="button dynamic-actions">DEACTIVATE</button>`;
	}
	else if(status == 'Inactive') {
		html = `<button type="button" data-action="plugs99_activate" data-name="`+name+`" data-key="`+key+`" class="button dynamic-actions">ACTIVATE</button>`;
	}
    else if(status == 'Expired') {
		html = `<button type="button" data-action="plugs99_activate" data-name="`+name+`" data-key="`+key+`" class="button dynamic-actions">ACTIVATE</button>`;
	}
	else if(status == '' ) {
		html = `<button type="button" data-action="plugs99_activate" data-name="`+name+`" data-key="`+key+`" class="button dynamic-actions">ACTIVATE</button>`;
	}
	// key or name is blank
	if(name == '' || key == '') html = '';

	$parent.find('.prime-actions').html( html );
	$parent.find('[name*=status]').val( status );
	$parent.find('.response_status').html( status == '' ? 'Inactive' : status );
}