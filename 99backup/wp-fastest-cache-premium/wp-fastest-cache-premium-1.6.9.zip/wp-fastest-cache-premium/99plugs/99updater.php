<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

define('P99_5172', 'WP Fastest Cache Premium');

if (class_exists('Plugs99_Plugin_Updater') && function_exists('p99_fetchkey')) {
  function p99_update_5172() {
    $doing_cron = defined('DOING_CRON') && DOING_CRON;
    if (!current_user_can('manage_options') && !$doing_cron) {
      return;
    }
    $key = p99_fetchkey(P99_5172);
    
    $edd_updater = new Plugs99_Plugin_Updater('https://99plugs.com/', PMAIN_5172, array(
      'version' => "1.6.9",
      'license' => $key,
      'item_id' => "5172",
      'author' => "Emre Vona",
      'url' => home_url()
    ));
  }
  add_action('init', 'p99_update_5172');
}

function p99_filter_5172($transient) {
  if (isset($transient) && is_object($transient)) {
    if (isset($transient->response[plugin_basename(PMAIN_5172)])) {
      if (strpos($transient->response[plugin_basename(PMAIN_5172)]->package, '99plugs') !== false) {
      } else {
        unset($transient->response[plugin_basename(PMAIN_5172)]);
      }
    }
  }
  return $transient;
}
add_filter('pre_set_site_transient_update_plugins', 'p99_filter_5172');
add_filter('pre_site_transient_update_plugins', 'p99_filter_5172');
add_filter('site_transient_update_plugins', 'p99_filter_5172');

add_filter('http_request_args', function ($r, $url) {
  if (0 === strpos($url, 'https://api.wordpress.org/plugins/update-check/1.1/')) {
    $plugins = json_decode($r['body']['plugins'], true);
    if (array_key_exists(plugin_basename(PMAIN_5172), $plugins['plugins'])) {
      unset($plugins['plugins'][plugin_basename(PMAIN_5172)]);
    }
    $r['body']['plugins'] = json_encode($plugins);
  }
  return $r;
}, PHP_INT_MAX, 3);

if (!function_exists('p99_dupechk')) {
  function p99_dupechk($needle, $haystack, $strict = false) {
    if(is_array($haystack)) {
      foreach ($haystack as $item) {
        if (($strict ? $item === $needle : $item == $needle)
        || (is_array($item) && p99_dupechk($needle, $item, $strict))) {
          return true;
        }
      }
    }
    return false;
  }
}
function p99_add2mgr_5172() {
  $apikeys = get_option('apikeys');
  $new_key = array();

  if (!p99_dupechk(P99_5172, $apikeys)) {
    $new_key['keyname'] = stripslashes(strip_tags(P99_5172));
    $new_key['keyvalue'] = '';
    $new_key['keystatus'] = '';
    $apikeys[] = $new_key;
  }
  if (!empty($new_key) && $new_key != $apikeys) {
    update_option('apikeys', $apikeys);
  }
}
register_activation_hook(PMAIN_5172, 'p99_add2mgr_5172');
