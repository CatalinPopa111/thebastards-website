<?php
	class WpFastestCacheDelayJS{
		private $tags = array();
		private $external_js_list = array(
			"\/\/apps\.elfsight\.com\/p\/platform\.js",
			"\/\/app\.eu\.usercentrics\.eu\/browser-ui\/latest\/loader.js",
			"\/\/cdn\.iubenda\.com\/cs\/gpp\/stub\.js",
			"\/\/cdn\.iubenda\.com\/cs\/iubenda_cs\.js",
            "\/\/cdn\-cookieyes\.com\/client_data\/[^\/]+\/script\.js", // https://cdn-cookieyes.com/client_data/98d628abbf56ac1b21091a7c/script.js
            "\/\/connect\.livechatinc\.com\/api\/[^\/]+\/script\/[^\/]+\/widget\.js", // https://connect.livechatinc.com/api/v1/script/5f9a2753-6a3e-4594-a867-e61f99b773e6/widget.js?lcv=af1aa836-6a44-4013-8944-05d402c980f1
            "\/\/js\.chargebee\.com\/[^\/]+\/chargebee\.js",
            "\/\/assets\.pinterest\.com\/js\/pinit\.js",
			"\/\/sdki\.truepush\.com\/sdk\/[^\/]+\/app\.js", // https://sdki.truepush.com/sdk/v2.0.3/app.js
			"\/\/static\.zdassets\.com\/ekr\/snippet\.js",
			"\/\/www\.googletagmanager\.com\/gtag\/js\?id\=",


			"\/wp\-content\/plugins\/chaty\/js\/cht\-front\-script\.min\.js",
			"\/wp\-content\/plugins\/contact\-form\-7\/includes\/swv\/js\/index\.js",
			"\/wp\-content\/plugins\/contact\-form\-7\/includes\/js\/index\.js",
			"\/wp\-content\/plugins\/cookie\-notice\/js\/front\.min\.js",
			"\/wp\-content\/plugins\/table\-of\-contents\-plus\/front\.min\.js", 

			"\/wp\-content\/plugins\/woocommerce\/assets\/js\/frontend\/add\-to\-cart\.min\.js",
			"\/wp\-content\/plugins\/woocommerce\/assets\/js\/frontend\/add\-to\-cart\-variation\.min\.js",
		);

		public function __construct($html){
			$this->html = $html;
			$this->tags = $this->find_tags("<script", "</script>");
		}

		public function action(){
			$this->tags = array_reverse($this->tags);

			foreach ($this->tags as $key => &$value){

				$delayed_js = $this->delay_it($value["text"]);

				$this->html = substr_replace($this->html, $delayed_js, $value["start"], ($value["end"] - $value["start"] + 1));
			}

			return $this->html;
		}

		public function get_attributes($script){
			$attributes = new stdClass();

			preg_match_all("/\s+([^\s\=\'\"]+)\s*\=[\"\'\s]*([^\"\'\>]+)/i", $script, $parsed);

			if(isset($parsed[1][0])){
				foreach ($parsed[1] as $key => $value) {
					$attributes->$value = $parsed[2][$key];
				}
			}

			return $attributes;
		}

		public function delay_it($js){
			$attributes = $this->get_attributes($js);

			if(isset($attributes->src) && $this->in_external_js_list($attributes->src)){
				$middle_for_external = "(function(d,s){";
				$middle_for_external = $middle_for_external."var f=d.getElementsByTagName(s)[0];";
				$middle_for_external = $middle_for_external."j=d.createElement(s);";

				foreach ($attributes as $attr_key => $attr_value) {
					$middle_for_external = $middle_for_external."j.setAttribute('".$attr_key."', '".$attr_value."');";
				}

				$middle_for_external = $middle_for_external."f.parentNode.insertBefore(j,f);";
				$middle_for_external = $middle_for_external."})(document,'script');";
			}else if($tmp_inline_js = $this->in_inline_js_list($js)){
				$tmp_inline_js = preg_replace("/^<script[^\>]*>|<\/script>$/i", "", $tmp_inline_js);
								
				$middle_for_external = $tmp_inline_js;
			}

			if(isset($middle_for_external)){
				$js = str_replace("{{MIDDLE}}", $middle_for_external, $this->get_delay_inline_js_code());
			}

			return $js;
		}

		public function in_inline_js_list($js = false){
			if(!$js){
				return false;
			}

			if(preg_match("/<script[^\>]*>\s*\(\s*function\([wdsli\s\,]+\)\s*\{\s*w\[l\]\s*\=\s*w\[l\]\s*\|\|\s*\[\];\s*w\[l\]\.push\(\s*\{\s*[\"\']\s*gtm\.start\s*[\"\'][^\}]+\s*\}\s*\)[^\}]+\s*\}\s*\)\([^\)]+\)\s*\;\s*<\/script>/i", $js)){
				// (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
				// new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
				// j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
				// 'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
				// })(window,document,'script','dataLayer','GTM-M2QGN6H');

				return $js;
			}

			if(preg_match("/<script[^\>]*>\s*var\s+Tawk_API\s*\=\s*Tawk_API\s*\|\|\s*\{\}[\,\;\s]+(var)*\s*Tawk_LoadStart\s*\=\s*new\s+Date\(\)\s*\;\s*\(function\(\)\{[^\}]+\}\s*\)\(\)\s*\;\s*<\/script>/i", $js)){
				// <script type="text/javascript">
				// var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
				// (function(){
				// var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
				// s1.async=true;
				// s1.src='https://embed.tawk.to/63f4e6a831ebfa0fe7ee85a6/1gpqaa15b';
				// s1.charset='UTF-8';
				// s1.setAttribute('crossorigin','*');
				// s0.parentNode.insertBefore(s1,s0);
				// })();
				// </script>

				// <script id="tawk-script">
				// var Tawk_API=Tawk_API||{};
				// var Tawk_LoadStart=new Date();
				// (function(){
				// var s1=document.createElement('script'),s0=document.getElementsByTagName('script')[0];
				// s1.async=true;
				// s1.src='https://embed.tawk.to/61e7e3ebb84f7301d32bcc96/1fpot4ks0';
				// s1.charset='UTF-8';
				// s1.setAttribute('crossorigin','*');
				// s0.parentNode.insertBefore(s1, s0);
				// })();</script>

				return $js;
			}

			if(preg_match("/<script[^\>]*>\s*\!function\([fbevnts\,\s]+\)\{(((?!\.insertBefore\().)+)\.insertBefore\([^\)]+\)\}\([^\)]+fbevents\.js[^\)]+\);\s*(fbq\([^\)]+\)\s*\;\s*){2}\s*<\/script>/is", $js)){
				// <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
				// n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
				// n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
				// t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
				// document,'script','https://connect.facebook.net/en_US/fbevents.js');</script>

				// <script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
				// n.callMethod.apply(n,arguments):n.queue.push(arguments)};
				// if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
				// n.queue=[];t=b.createElement(e);t.async=!0;
				// t.src=v;s=b.getElementsByTagName(e)[0];
				// s.parentNode.insertBefore(t,s)}(window, document,'script',
				// 'https://connect.facebook.net/en_US/fbevents.js');
				// fbq('init', '305619320703136');
				// fbq('track', 'PageView');</script>

				return $js;
			}

			if(preg_match("/<script[^\>]*>\s*(fbq\([^\)]+\)\;\s*){2}document\.addEventListener\(/i", $js)){
				// <script>
				// fbq('init', '649269165501775', {}, {
				// "agent": "woocommerce-7.4.0-3.0.12"
				// });
				// fbq('track', 'PageView', {
				// "source": "woocommerce",
				// "version": "7.4.0",
				// "pluginVersion": "3.0.12"
				// });
				// document.addEventListener('DOMContentLoaded', function(){
				// jQuery&&jQuery(function($){
				// $(document.body).append('<div class=\"wc-facebook-pixel-event-placeholder\"></div>');
				// });
				// }, false);
				// </script>

				$js = preg_replace("/document\.addEventListener\(\s*[\'\"]\s*DOMContentLoaded\s*[\'\"]\s*,\s*function\(\)\{(((?!\}\s*,\s*false\s*\)\s*;).)+)\}\s*,\s*false\s*\)\s*;/is", "$1", $js);


				return $js;
			}

			if(preg_match("/<script[^\>]*>\s*\(\s*function\([^\)]+\)\{\s*[^\{]+function\(\)\{[^\}]+\}[^\}]+\}\s*\)\s*\([^\)]+mc\.yandex\.ru\/metrika\/tag\.js[^\)]+\)\s*\;\s*ym\([^\)]+\)\s*\;\s*<\/script>/", $js)){
				// <script defer >(function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
				// m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
				// (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
				// ym(89601392, "init", {
				// clickmap:true,
				// trackLinks:true,
				// accurateTrackBounce:true
				// });</script>

				return $js;
			}

			return false;
		}

		public function get_delay_inline_js_code(){
			$script = "<script data-wpfc-render=\"false\">";
			$script = $script."(function(){";
			$script = $script.'let events=["mouseover", "mousemove", "wheel", "scroll", "touchstart", "touchmove"];';
			$script = $script."let fired = false;";

			$script = $script."events.forEach(function(event){";
			$script = $script."window.addEventListener(event, function(){";
			$script = $script."if(fired === false){";
			$script = $script."fired = true;";

			$script = $script."{{MIDDLE}}";

			$script = $script."}";
			$script = $script."},{";
			$script = $script."once: true";
			$script = $script."});";
			$script = $script."});";
			$script = $script."})();";
			$script = $script."</script>";

			return $script;
		}

		public function in_external_js_list($src = false){
			if(!$src){
				return false;
			}

			foreach ($this->external_js_list as $key => $value) {
				if(preg_match("/".$value."/i", $src)){
					return true;
				}
			}

			return false;
		}

		public function find_tags($start_string, $end_string){
			if(!$this->html){
				return array();
			}else{
				$data = $this->html;
			}

			$list = array();
			$start_index = false;
			$end_index = false;

			for($i = 0; $i < strlen( $data ); $i++) {
			    if(substr($data, $i, strlen($start_string)) == $start_string){
			    	if(!$start_index && !$end_index){
			    		$start_index = $i;
			    	}
				}

				if($start_index && $i > $start_index){
					if(substr($data, $i, strlen($end_string)) == $end_string){
						$end_index = $i + strlen($end_string)-1;
						$text = substr($data, $start_index, ($end_index-$start_index + 1));
						

						array_push($list, array("start" => $start_index, "end" => $end_index, "text" => $text));


						$start_index = false;
						$end_index = false;
					}
				}
			}

			return $list;
		}

	}
?>