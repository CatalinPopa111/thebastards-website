=== Yoast SEO - Advanced SEO with real-time guidance and built-in AI ===
Contributors: yoast, joostdevalk, tdevalk
Donate link: https://yoa.st/1up
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
Tags: SEO, XML sitemap, Content analysis, Readability, Schema
Tested up to: 6.9
Stable tag: 26.8
Requires PHP: 7.4

Improve your SEO with real-time feedback, schema, and clear guidance. Upgrade for AI tools, Google Docs integration, and 24/7 support, no hidden fees.

== Description ==

## Yoast SEO: The #1 WordPress SEO Plugin

Since 2008, **Yoast SEO** has helped millions of websites worldwide improve their visibility and SEO performance.  
Our mission is **SEO for Everyone** — from small local businesses to some of the most visited sites on the web.

Yoast SEO gives you everything you need to manage your on-site SEO effectively.  
The [Yoast SEO Premium](https://yoa.st/1v8) plugin and its extensions unlock even more advanced and AI-powered tools.

---

### Handing you the competitive edge

SEO is the most consistent and cost-effective source of website traffic — but it can be complex. Whether you're just starting out or an advanced user, Yoast SEO helps you handle SEO confidently and efficiently.

Don't have time to stay on top of AI search and best practices? Keeping Yoast SEO updated means you automatically benefit from ongoing technical improvements, schema updates, and AI advancements — all guided by our signature traffic light approach.

Empower search engines to better understand your website using **Schema.org structured data integration**, and access in-depth content and readability analysis tools that help you create content designed to perform well in search.

---

### Quick and easy setup

Setting up Yoast SEO is quick and straightforward — no technical background required.  
Our step-by-step configuration wizard walks you through essential setup details so Yoast SEO can generate accurate **structured data** that helps search engines understand your site.

Switching from another SEO plugin like Rank Math or AIOSEO? Migration is seamless.  
Import your existing SEO data and settings safely with our built-in import/export tools.

---

### Content and AI features

Unlock your content's full potential with Yoast SEO's **advanced content analysis** and **AI-powered tools**.

**Content optimization features:**
- Detailed **SEO analysis** to guide keyword targeting and site performance.
- **Readability analysis** for clear, engaging, and user-friendly writing.
- **SERP previews** for both desktop and mobile results.
- **HowTo and FAQ blocks** with built-in schema support.
- **Breadcrumbs block** for improved navigation.
- **Inclusive Language Analysis** to make your content more considerate and accessible.
- **Semrush integration** for keyword research directly in Yoast SEO.
- **Wincher integration** to track keyword performance inside your dashboard.
- **Elementor integration** for seamless optimization within your favorite builder.

**AI features (included in Premium):**
- **[Yoast AI Generate](https://yoa.st/51c)** – Instantly create five SEO-friendly titles and meta descriptions, with one-click regeneration for more options.
- **Yoast AI Optimize** – Improve keyphrase placement (introduction, distribution, density) automatically.
- **Yoast AI Summarize** *(New 2025)* – Generate quick content summaries for briefs or social posts.
- **All AI tools included** – No extra accounts, limits, or hidden costs.

These tools help you craft optimized, helpful content that resonates with readers and performs strongly across search platforms.

---

### Taking care of your technical SEO

Yoast SEO automatically handles much of your site's technical SEO, freeing you to focus on your content.

**Key technical SEO features:**
- Automated **meta tag optimization** right out of the box.
- **Canonical URLs** to prevent duplicate content issues.
- **Advanced XML sitemaps** for clear site indexing.
- **Best-in-class Schema.org integration** to improve search understanding and appearance.
- Complete **breadcrumb control** for visitors and crawlers.
- **Performance improvements** that help reduce load times.
- **Crawl settings** to manage how bots access your site and reduce environmental impact.
- **LLMs.txt management** to guide how large language models interact with your content.

Every update delivers ongoing technical SEO enhancements automatically.

---

### Keep your website in perfect shape

Whether you're a creator, business owner, or developer, Yoast SEO helps maintain your website's SEO health:

- **Cornerstone content tools** to organize and prioritize key pages.
- **Front-end SEO inspector** to view and edit titles, descriptions, and schema live.
- **SEO roles** to delegate plugin access securely across teams.
- **Regular 2-week update cycle** to ensure compatibility with the latest SEO standards and search engine changes.

---

### Powerful integrations

Yoast SEO works seamlessly with popular WordPress tools to enhance your workflow and results:

- **[Google Site Kit](https://en-gb.wordpress.org/plugins/google-site-kit/):** Access insights from Search Console, Analytics, and PageSpeed directly inside WordPress.
- **[Advanced Custom Fields (ACF)](https://wordpress.org/plugins/advanced-custom-fields/):** Combine with [ACF Content Analysis for Yoast SEO](https://wordpress.org/plugins/acf-content-analysis-for-yoast-seo/) for advanced field optimization.
- **[Elementor](https://wordpress.org/plugins/elementor/):** Use full Yoast SEO functionality inside Elementor's editor.
- **[Algolia](https://wordpress.org/plugins/wp-search-with-algolia/):** Enhance internal search accuracy and performance.
- **[Semrush](https://www.semrush.com/):** Discover and optimize for high-value keywords.
- **[Wincher](https://wincher.com/):** Track keyword positions and trends in Google Search.
- **[Jetpack](https://wordpress.org/plugins/jetpack/):** Manage SEO and social previews all in one place.
- **[Easy Digital Downloads (EDD)](https://en-gb.wordpress.org/plugins/easy-digital-downloads/):** Improve digital product visibility with integrated schema.
- **[Mastodon](https://mastodon.social/):** Verify your website on Mastodon with Yoast SEO Premium.
- **[WooCommerce](https://en-gb.wordpress.org/plugins/woocommerce/):** Optimize ecommerce SEO with the dedicated WooCommerce extension.

---

## Yoast SEO Premium – AI-powered SEO for WordPress

[Yoast SEO Premium](https://yoa.st/1v8) enhances everything in Yoast SEO with advanced automation, AI tools, and professional support.  
Trusted by millions, it helps you optimize efficiently for both traditional and AI-driven search.

**Tackle your SEO challenges:**
- Keep pace with algorithm and AI search updates.
- Target the right audience effectively.
- Automate redirects, crawl controls, and internal linking.
- Identify orphaned content and improve site structure.
- Get support when you need it.

**Premium highlights:**
- AI-generated titles and meta descriptions.
- Smart internal linking suggestions.
- Social previews for Facebook and X.
- **Redirect Manager** with bulk tools and automatic prompts.
- **Bot Blocker** for AI crawlers (GPTBot, CCBot, Google-Extended).
- **IndexNow** integration for fast content updates.
- **Front-end SEO Inspector** for real-time editing.
- **SEO Workouts** to improve orphaned and cornerstone content.
- [**Google Docs add-on**](https://yoa.st/52u) for seamless SEO writing in Docs.
- **24/7 premium support** from SEO specialists.

**Includes at no extra cost:**
- [Yoast Local SEO](https://yoa.st/1uu): Optimize for local audiences and Google Maps.
- [Yoast Video SEO](https://yoa.st/1uw): Ensure Google understands your videos with video sitemaps and schema.
- [Yoast News SEO](https://yoa.st/1uv): Increase visibility in Google News and Top Stories.

---

## Yoast WooCommerce SEO – Advanced SEO for Online Stores

**Yoast WooCommerce SEO** builds on Yoast SEO Premium with ecommerce-specific tools to improve your store's visibility and conversion potential.

**Key ecommerce SEO features:**
- **WooCommerce-specific XML sitemap** excluding non-shopping content.
- **Product structured data** for enhanced rich results (price, reviews, availability).
- **Canonical URL management** to prevent duplicates.
- **Ecommerce-focused content analysis** for GTINs, SKUs, and short descriptions.
- **AI Generate for ecommerce** – Instantly create optimized titles and meta descriptions for product and category pages.

**Benefits:**
- Improve product visibility with automated structured data.
- Enhance crawl efficiency for large catalogs.
- Save time through metadata templates and automation.
- Increase engagement with AI-optimized ecommerce metadata.

Built for WooCommerce, trusted by thousands of online stores worldwide.

---

## For Developers

Yoast SEO is built with developers in mind. With modern APIs, hooks, and a unified indexables system, you can extend or integrate SEO functionality across custom themes, plugins, or headless setups.

### REST API
Retrieve SEO metadata for any post or URL, including meta tags, Open Graph, Twitter Cards, and Schema.org data.  
[Learn more about the REST API](https://yoa.st/53l).

### Surfaces API
Access SEO data directly in code via `YoastSEO()->meta->for_current_page()`.  
Supports titles, descriptions, canonicals, and schema.  
[Read the Surfaces API documentation](https://yoa.st/53m).

### Metadata API
Use the [Metadata API](https://yoa.st/53n) to filter, override, or extend meta tags with WordPress hooks such as `wpseo_title`, `wpseo_metadesc`, and `wpseo_canonical`.

### Schema API
The [Schema API](https://yoa.st/53o) lets you modify or extend Schema.org graph pieces, including Article, Organization, Person, Breadcrumb, and WebPage entities.

### Block Editor compatibility
Yoast SEO integrates directly with the WordPress Block Editor (Gutenberg).  
It outputs schema for HowTo and FAQ blocks by default, and developers can extend schema for custom blocks.

### Indexables
At the core of Yoast SEO lies the [indexables system](https://yoa.st/53q), unifying all SEO data for faster queries and consistent metadata across outputs.

---

## Ongoing support and education

Yoast is powered by expert developers, testers, and SEO specialists who keep improving the plugin.  
We're committed to helping users grow their SEO skills with resources such as:

- [Yoast SEO Academy](https://yoa.st/3ri): Free and premium SEO courses (included in all paid plans).
- [Yoast SEO blog](https://yoast.com/seo-blog/), newsletter, and webinars.
- [Yoast SEO Update podcast](https://yoa.st/53i) for the latest SEO insights.
- [Bug reports on GitHub](https://github.com/Yoast/wordpress-seo) (for issue tracking, not support).

**Yoast SEO** — built to make search optimization accessible, reliable, and ready for the future of AI search.

== Installation ==
Starting with Yoast SEO consists of just two steps: installing and setting up the plugin. Yoast SEO is designed to work with your site’s specific needs, so don’t forget to go through the Yoast SEO first-time configuration as explained in the ‘after activation’ step! For the most up-to-date guidance on how to install Yoast SEO products, [please visit our help center](https://yoast.com/help/yoast-installation-manuals/#h-yoast-seo-and-yoast-seo-premium-for-wordpress). 

== Frequently Asked Questions ==

= How do the XML Sitemaps in the Yoast SEO plugin work? =

Having an XML sitemap can be beneficial for SEO, as Google can retrieve essential pages of a website very fast, even if the internal linking of a site isn’t flawless.
The sitemap index and individual sitemaps are updated automatically as you add or remove content and will include the post types you want search engines to index. Post Types marked as noindex will not appear in the sitemap. [Learn more about XML Sitemaps](https://yoa.st/3qt).

= How can I add my website to Google Search Console? =

It is straightforward to add your website to Google Search Console.
1. Create a Google Search Console account and login into your account.
2. Click ‘Add a property’ under the search drop-down.
3. Enter your website URL in the box and click ‘Continue’.
4. Click the arrow next to ‘HTML tag’ to expand the option.
5. Copy the meta tag.
6. Log in to your WordPress website.
7. Click on ‘SEO’ in the dashboard.
8. Click on ‘General’.
9. Click on the ‘Webmaster Tools’ tab.
10. Paste the code in the Google field and click ‘Save Changes’.
11. Go back to Google Search Console and click ‘Verify’.

If you want more details steps, please visit [our article on our help center](https://yoa.st/3qu).

= How do I implement Yoast SEO breadcrumbs? =

The steps below are a temporary solution as manual edits made to theme files may be overwritten with future theme updates. Please contact the theme developer for a permanent solution. We’ve written an article about the [importance of breadcrumbs for SEO](https://yoa.st/3qv).

To implement the [breadcrumbs](https://yoa.st/3qw) function in Yoast SEO, you will have to edit your theme. We recommend that prior to any editing of the theme files, a backup is taken. Your host provider can help you take a backup.
Copy the following code into your theme where you want the breadcrumbs to be. If you are not sure, you will need to experiment with placement:

<code>
<?php
if ( function_exists( 'yoast_breadcrumb' ) ) {
    yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
}
?>
</code>

Common places where you could place your breadcrumbs are inside your `single.php` and/or `page.php` file just above the page’s title. Another option that makes it really easy in some themes is by just pasting the code in `header.php` at the very end.

In most non-WooTheme themes, this code snippet should not be added to your `functions.php` file.
Alternatively, you can manually add the breadcrumb shortcode to individual posts or pages: `[wpseo_breadcrumb]`

If you need more details or a step by step guide, read our [Implementation guide for Yoast SEO breadcrumbs](https://yoa.st/3qx).

= How do I noindex URLS? =

Yoast SEO provides multiple options for setting a URL or group of URLs to noindex. [Read more about how to do this in this guide](https://yoa.st/3qy/).

= Google shows the wrong description, how do I fix this? =

If you’ve crafted nice meta descriptions for your blog posts, nothing is more annoying than Google showing another description for your site completely in the search result snippet.

Possible causes could be:
1. wrong description in code
2. Google cache is outdated
3. Search term manipulation
4. Google ignored the meta description

You can [read more here on how to solve the issue with the wrong description](https://yoa.st/3qz).

= How often is Yoast SEO updated? =

Yoast SEO is updated every two weeks. If you want to know why, please read [this post on why we release every two weeks](https://yoa.st/3q-)!

= How do I get support? =

As our free plugin is used by millions of people worldwide, we cannot offer you all one on one support. If you have trouble with the Yoast SEO for WordPress plugin, you can get help on the support forums here at [wordpress.org](https://wordpress.org/support/plugin/wordpress-seo/) or by checking out our help center at [yoast.com/help/](https://yoa.st/3r1).

The plugins you buy at Yoast are called ‘premium plugins’ (even if Premium isn’t in its name) and include a complete year of free updates and premium support. This means you can contact our support team if you have any questions about that plugin.

[Read more on how to get support](https://yoa.st/3r2)

= What happens to my data if I enable usage tracking? =

[This page on yoast.com explains what data we collect to improve Yoast SEO](https://yoa.st/4w7). We only collect data when you explicitly opt in. Read more about how we handle your data in [our Privacy Policy](https://yoa.st/4w8).

= I have a different question than listed here =

Your question has most likely been answered on our help center: [yoast.com/help/](https://yoa.st/1va).

== Screenshots ==

1. The modern interface makes Yoast SEO easy to work with.
2. Easily manage how your posts and pages appear in SERPs.
3. Yoast SEO Premium has extra crawl optimization options.
4. Yoast SEO integrates with tools like Semrush and Wincher.
5. The famous SEO and readability analyses in Yoast SEO.
6. See what your post looks like in Google.
7. The First-time configuration helps you get started quickly.
8. The inclusive language analysis in Yoast SEO.

== Changelog ==

= 26.8 =

Release date: 2026-01-20

Yoast SEO 26.8 brings more enhancements and bugfixes. [Find more information about our software releases and updates here](https://yoa.st/releases).

#### Enhancements

* Adds a schema settings page to allow users more control over the Yoast Schema Framework API.
* Implements a new, easy-to-use design for the site features settings.

#### Bugfixes

* Fixes a bug where inserting Yoast blocks via Content blocks collapsible was not possible when editing in `template-locked` mode inside Block Editor.
* Fixes a bug where the alert for signing up to the newsletter didn't support rtl direction for buttons and inputs in RTL languages.
* Fixes a bug where the assessments highlighting feature did not work when editing in template-locked mode in the Block Editor.
* Fixes a bug where the Search and Social appearance modals looked off on WordPress 7.0 or with Gutenberg 22.3.0.
* Fixes a bug where WordPress link classes were not being recognized when Yoast SEO was active. Props to [benoitchantre](https://github.com/benoitchantre).

#### Other

* Adds an opt-in notification for the task list feature on the general page.
* Improves the translatability of some tasks' title in the task list.
* Replaces Yoast product logos with new designs across the plugin’s interface.
* Updates the product URL inside the marker presenter for Yoast SEO and Yoast SEO Premium.

= 26.7 =

Release date: 2026-01-07

*New:* Yoast SEO (free) now includes full access to the Site Kit by Google integration in your Dashboard. [Read the full release post here](https://yoa.st/551).

#### Enhancements

* Changes the Schema output to render `Article` entities even when the `publisher` property is left empty.
* Rolls out the Site Kit integration for all Yoast users.

#### Bugfixes

* Fixes a bug where the Yoast AI consent modal would incorrectly pop up when interacting with unrelated buttons or fields on Profile setting page.

#### Other

* Hides the llms.txt task in multisites, since the feature is disabled in such setups.
* Increases disabling opcache invalidation on plugin upgrade, now applied to a bigger subset of the userbase.

= Earlier versions =
For the changelog of earlier versions, please refer to [the changelog on yoast.com](https://yoa.st/yoast-seo-changelog).
